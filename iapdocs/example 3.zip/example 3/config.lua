application = {
	content = {
		width = 320,
		height = 480, 
		scale = "letterBox",
		fps = 30,
		
		--[[
        imageSuffix = {
		    ["@2x"] = 2,
		}
		--]]
	},

        license =
        {
            google =
            {
                key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqdBA9x8WicYYoyya7TymqDthp1RmeJ1MH/tV3IWLChuzg2qn67tfOvnWP29FDuruxgqxca0JlCEk3QRTaUv7tLMDbt0/38GbWo3BSx7adFOm7tSXR6LTlMt4m5te1BleLKnohh6rM2VlBo5lG+Yu9Wl1RMeO6e8IcFRqZGqZGd2gJieuU8zZL7iSq74FKNBhwYIrKgXQbnEa0olG/uNkGvNDgT/q5HlT02M8leTQTMVe/phSRWEm1ouVpE92XpE94xw4HDhgP0FiMuTF4xBAMgPYOh/KRHEKWUPaBxOwwZDNpnAShg32lDApJwf6pLRjZVcfzB5012YT9M8iIAtM9QIDAQAB",
                policy = "serverManaged",
            },
        },        
        
    --[[
    -- Push notifications

    notification =
    {
        iphone =
        {
            types =
            {
                "badge", "sound", "alert", "newsstand"
            }
        }
    }
    --]]    
}
